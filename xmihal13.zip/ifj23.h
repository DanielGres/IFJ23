// Implementace překladače imperativního jazyka IFJ23
// Daniel Greš --- xgresd00
// Mário Mihál --- xmihal13
// Viktor Hančovský --- xhanco00
// Branislav Kotúč --- xkotuc02

#include <stdio.h>
#include "tok_tree.h"
#include "syntax.h"
#include "codegen.h"
#include "miscellaneous.h"